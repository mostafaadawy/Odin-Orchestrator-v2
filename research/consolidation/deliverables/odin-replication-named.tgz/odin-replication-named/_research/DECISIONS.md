# Decisions made autonomously (2026-10-06) — for the owner's review

D1. The paper is anonymous ("Keel") and named (Odin), and rests only on our own measured results. The benchmark rank is omitted, because no source was found. The framework from the failure timeline is called "a widely used multi-agent framework", with no name and no outside figures.
D2. REVISED. Without its database, the copy listed 0 projects and the /ui endpoints returned 500 ("the database is the only registry"), so real runs were impossible. I did NOT touch your PostgreSQL server (5432). Instead I created a PRIVATE, throwaway PostgreSQL 14 cluster that belongs only to the copy: port 15432, data under `_research/tmp/pg` (`_isolation/pg_up.sh`).
   - It was filled from a READ-ONLY `pg_dump` of odin_core (schema and data) and of odin_anchor (schema only). Before restoring, the dump was re-pathed to Odin-Isolated and scanned for secrets (none found).
   - Your databases were only read. Your own odin_core still shows 11 projects after the dump.
   - The copy's processes reach the private cluster through PGHOST/PGPORT.
   - Experiments use a second private cluster (port 15433), which is reset from the same dump before each trial.
   - Please confirm you accept this reading of "no database update".
D3. Cloud and remote tools are blocked for every process in the copy: shims for az, ssh, scp, sftp, rsync, sshpass and gh in `_isolation/shims`, each logging to `_isolation/blocked_calls.log`. This was verified inside a Claude agent's Bash. The copy also has no credentials. So no test can change the cloud. Any test step that needs the VM is reported as "skipped (cloud blocked)".
D4. The isolated server runs on port 18000 with voice off and Claude auto-memory off. The temporary experiment servers run on 181xx, each in its own throwaway root under `_research/tmp/`. That folder is the only place deletes happen.
D5. Measurements report ratios, not absolute numbers. Each run records the M4 environment (CPU model, core count, RAM, OS), the process's own CPU time and memory, the system load, and whether the real Odin server or the SOC agents were active.
D6. INCIDENT, fixed (copy only, real folder untouched). A setup bug left one experiment trial with an empty root path, so it ran against Odin-Isolated itself instead of a throwaway root.
   - Effect: 2 test projects (cx9-n2-p*) and 13 promoted test utilities were created, and 2 history logs had lines appended.
   - Repair: the logs were restored with git checkout from the copy's baseline. The test files were MOVED (not deleted) to `_research/tmp/accident_quarantine`. Git status of the copy is clean again.
   - Prevention: every experiment and regression script now refuses to run unless its root is under `_research/tmp` and contains `server/`.
D7. Isolation fix. `server/run.sh` puts Homebrew FIRST on PATH, so the PATH shims were bypassed by servers started through run.sh. The shims (az, ssh, scp, sftp, rsync, sshpass, gh, plus the claude cost-recording wrapper) are now also installed in the copy's `.venv/bin`, which run.sh puts first. All servers were restarted and the shims re-verified from inside a server-spawned agent. Before this fix, only one pilot run (a local file-writing task) had used a server. Its transcript shows no remote command. `_isolation/blocked_calls.log` was empty.
D8. Job B (vector signal for finding reusable scripts) is written as a proposal with a benchmark protocol, NOT run. A fair benchmark needs labels you write yourself; the old labels were dropped on your instruction, and labels I invented would bias the result. (`05_proposals.md`, P4.)
D9. Your end-to-end scripts:
   - `phase7_lifecycle.py` was run unmodified, 3 repetitions.
   - `sandbox_revealer_multiagent.py` was run as a LOCAL adaptation (`_research/exp/sandbox_revealer_local.py`). The original deploys to the Azure VM, which is a cloud change and a STOP condition, so steps 3–5 deploy to 127.0.0.1:8531 instead, and the provider keys are blank. The scorecard code is unchanged.
   - NOT run: `real_production_deploy_devops_only.py` (production is forbidden), and `readonly_shipping_vq_status.py` / `readonly_email_klaviyo_workflows.py`, which need live provider keys that the isolated copy does not have by design.
D10. The named paper uses placeholders for your affiliation and e-mail ("to be confirmed"). You said not to ask until the end, and the earlier cover note's "Odin Group, Cairo" was never confirmed.
D11. The LLM runs use Odin's own per-scope model control set to `haiku`, to keep cost low.
   - Repetition 0 at N=10 reused 5 task names. That exposed agents from different projects overwriting each other in a shared root `code/` folder: 4 name collisions, 8 projects affected. This is reported as an observation.
   - Repetitions 1–2 use unique module names, so collisions by name cannot recur.
D12. Router agreement was measured for the deterministic keyword dispatcher only. The semantic router needs the local Ollama model, which was not started in the isolated copy.
D13. Experiment roots and the private Postgres clusters live under `_research/tmp` (the temp folder). They are removed after the replication package is built. Raw results stay in `_research/results`.
D14. FINDING and cleanup (copy only). In repetition 2, 2 of the 36 LLM project runs (p0 at N=5 and p0 at N=10) wrote their module into the main isolated copy (`Odin-Isolated/workspace/projects/<pid>/code`) instead of their throwaway root.
   - Cause: the copy's CLAUDE.md gives the repository's ABSOLUTE path, and the agent followed it.
   - The files landed in the correct slot of the canonical workspace, which is right in production but escapes the experiment root.
   - The files were moved (not deleted) to `_research/tmp/accident_quarantine/escaped_llm`. The copy's audit-log changes made by its own server were reverted with git. The isolated server (18000) is stopped when not needed.
   - This is reported in the paper as an observation about agents following absolute paths. Your owner tests were re-run after the cleanup.
D15. Escape guard: while your LLM-driven test runs, the main copy's `workspace/` is made read-only (`chmod a-w`) and restored afterwards, so an agent that follows an absolute path cannot write into the copy.
D16. `phase7_prompt4.py` (your 4-project prompt journey) was run with specs A–C only (`_research/exp/phase7_prompt4_local.py`). Spec D asks the system to "set up a sandbox deployment", which would be a remote/cloud change, a STOP condition. Everything else is unchanged, including autoApprove and the acceptance checks.
