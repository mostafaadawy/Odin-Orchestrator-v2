# Replication package: "Consistency by Construction" (named version)

Everything here ran on an ISOLATED copy of the system (Odin-Isolated): no credentials, cloud and remote tools blocked, and a private throwaway PostgreSQL restored from a read-only dump.

| Path | Content |
|---|---|
| `_research/exp/` | Experiment code:<br>• `consistency_trial.py` and `consistency_run.sh` (RQ1)<br>• `llm_exp.py`, `llm_series.sh`, `llm_trial.sh`, `llm_root_up.sh` and `analyze_llm.py` (RQ2)<br>• `anchor_exp.py` (RQ4)<br>• `common.py` (environment snapshot, per-PID CPU meter, stage time-tags, cost ledger)<br>• `mkroot.sh` (throwaway roots)<br>• `aggregate.py` |
| `_research/regression/` | `regress.py` (18 checks) and `baseline.json` |
| `_research/results/` | All raw results: trials, LLM call ledgers (cost and tokens), owner-test logs, the environment and SOC-run log, and `summary.json` |
| `workspace/shared/testing/` | The owner's end-to-end scripts that were run (unmodified). The isolated adaptations are in `_research/exp/*_local.py`. |
| `_isolation/` | How the copy was isolated: `ISOLATION.md`, the shims, `up.sh`, `pg_up.sh`, and the log of blocked remote calls |
| `paper/` | LaTeX source and both PDFs. Rebuild with `pdflatex`, `bibtex`, then `pdflatex` twice. Figures come from `make_figs.py` reading `results/`. |
| `_research/DECISIONS.md` | Every decision taken autonomously, for the owner's review |

How to reproduce RQ1:
1. `_isolation/pg_up.sh 15433 --restore`
2. `_research/exp/consistency_run.sh`
3. `.venv/bin/python _research/exp/aggregate.py`

Total model cost of the study: about 5.72 USD.
