# Replication package: "Consistency by Construction" (anonymised version)

Everything here ran on an ISOLATED copy of the system (SYSTEM-isolated). The copy had no credentials, cloud and remote tools were blocked, and the database was a private throwaway PostgreSQL restored from a read-only dump. No database dump, record, key, e-mail or IP address is included.

| Path | Content |
|---|---|
| `_research/exp/` | Experiment code. RQ1: `consistency_trial.py`, `consistency_run.sh`. RQ2: `llm_exp.py`, `llm_series.sh` (REP, NS, ADV, KEEL_SCOPE_HOOK), `llm_trial.sh`, `llm_root_up.sh`, `analyze_llm.py`. RQ3 (owner tests, isolated adaptations): `*_local.py`, `revealer_run.sh`, `prompt4_run.sh`, `after_owner_tests.sh`. RQ4: `anchor_exp.py`. Shared: `common.py`, `mkroot.sh`, `aggregate.py`. Bug repro: `repro_delete.py`. Promotion package builder: `make_promotion.sh`. |
| `_research/regression/` | `regress.py` (32 checks; the first 18 are the baseline) and `baseline.json` |
| `_research/results/` | All raw results. Reps 0–2 = before; 10–11 = watch; 20–22 = after; 30 = adversarial, hook off; 31/32 = adversarial, hook on (first / final hook). Owner-test logs `*_after*`. `summary.json` aggregates everything. `*_invalid` / `*_aborted` logs are excluded from the analysis (see the decision log). |
| `_research/promotion/` | The promotion package: 5 patches against the production files, README, final regression result |
| `server/` | The two new files of P2b (`scope_hook.py`, `door_cli.py`) |
| `workspace/shared/testing/` | The owner's end-to-end scripts that were run (unmodified) |
| `_isolation/` | How the copy was isolated |
| `paper/` | LaTeX source and both PDFs (`pdflatex`, `bibtex`, `pdflatex` ×2; figures from `make_figs.py`) |

Total model cost of the study: 16.46 USD.
