#!/usr/bin/env python3
"""Flatten the named LaTeX build into pandoc_named.tex and convert it to main_named.docx.
Usage: python3 build_docx.py [path/to/ieee.csl]   (TikZ figures must exist as figs/tikz_*.png)."""
import re, subprocess, sys
def flat(path):
    s = open(path).read()
    s = '\n'.join(l for l in s.split('\n') if not l.lstrip().startswith('%'))
    def rep(m):
        f = m.group(1)
        if f.startswith('figs/tikz'):
            return '\\includegraphics[width=\\linewidth]{' + f + '.png}'
        if not f.endswith('.tex'):
            f += '.tex'
        return flat(f)
    return re.sub(r'\\input\{([^}]+)\}', rep, s)
s = flat('main.tex')
s = re.sub(r'\\ifanon(.*?)\\else(.*?)\\fi', lambda m: m.group(2), s, flags=re.S)
i = s.index('\\begin{document}')
title = re.search(r'\\title\{(.*?)\}\n', s).group(1)
body = s[i:]
body = re.sub(r'\\title\{.*?\}\n', lambda m: '', body, count=1)
body = re.sub(r'\\author\{.*?\n\\maketitle', lambda m: '\\maketitle', body, flags=re.S)
body = body.replace('\\resizebox{\\textwidth}{!}{%\n', '').replace('.png}}', '.png}')
body = re.sub(r'\{figs/(fig_[a-z0-9_]+)\}', r'{figs/\1.png}', body)
body = body.replace('\\hub{}', 'asynchronous Anchor integration hub').replace('\\bfx ', '\\textbf{Before fixes.} ')
body = body.replace('\\sys{}', 'Keel').replace('\\embmodel{}', 'all-MiniLM-L6-v2').replace('\\tlo', '\\tau_{lo}')
body = body.replace('\\textsc{new} &', '\\mathrm{NEW} &').replace('\\textsc{reuse}(b^{*})', '\\mathrm{REUSE}(b^{*})').replace('\\textsc{delta}(b^{*})', '\\mathrm{DELTA}(b^{*})')
body = re.sub(r'\\route\{(\w+)\}', lambda m: m.group(1).upper(), body)
body = body.replace('>{\\raggedright\\arraybackslash}', '').replace('\\footnotesize', '')
body = body.replace('\\begin{IEEEkeywords}', '\\textbf{Index Terms}---').replace('\\end{IEEEkeywords}', '')
body = body.replace('\\cmidrule(lr){3-5}\\cmidrule(l){6-8}', '\\midrule')
body = re.sub(r'\\multicolumn\{2\}\{@\{\}l\}\{\\emph\{(.*?)\}\}\\\\', lambda m: '\\emph{' + m.group(1) + '} & \\\\', body)
body = body.replace('\\quad\\quad ', '').replace('\\quad ', '')
body = body.replace('{figure*}', '{figure}').replace('{table*}', '{table}')
body = body.replace('\\eqref{eq:invariant}', '(3)').replace('\\eqref{eq:route}', '(2)')
pre = ('\\documentclass{article}\n\\usepackage{amsmath,amssymb,booktabs,graphicx}\n'
       '\\newcommand{\\todo}[1]{[TODO: #1]}\n\\title{' + title + '}\n')
open('pandoc_named.tex', 'w').write(pre + body)
cmd = ['pandoc', 'pandoc_named.tex', '-o', 'main_named.docx', '--number-sections', '--citeproc',
       '--bibliography=refs.bib', '--resource-path=.:figs',
       '-M', 'author=Mostafa A. M. Sayed Adawy, Odin Group, Cairo, Egypt (mostafa_adawy@ymail.com)']
if len(sys.argv) > 1:
    cmd.append('--csl=' + sys.argv[1])
subprocess.run(cmd, check=True)
